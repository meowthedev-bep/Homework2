#include <iostream>
#include <cmath> // Необхідно для математичних функцій
using namespace std;
int main() {
    double y;
    cout << "Введіть значення y: ";
    cin >> y;

    // Обчислення чисельника та знаменника
    double upper = cbrt(
        abs(y * y - 2) * 
        abs(sin(y * y * y)) * 
        abs(tan(y)) * 
        pow(2.5, cos(y))
    );

    double bottom = 0.625 * y + 2 * log2(y * y * y + 7.5);

    // Перевірка, щоб уникнути ділення на нуль
    if (bottom == 0) {
        cout << "Ділення на нуль!" << endl;
    } else {
        double y = upper / bottom;
        cout << "y = " << y << endl;
    }

    return 0;
}