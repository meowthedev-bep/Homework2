// #include <iostream>

// int main() {
//     int days_passed;
//     std::cout << "З початку місячного року: ";
//     std::cin >> days_passed;
//     int month = (days_passed - 1) / 28 + 1;
//     int day = (days_passed - 1) % 28 + 1;

//     std::cout << "Поточний місяць: " << month << std::endl;
//     std::cout << "Поточний день: " << day << std::endl;

//     return 0;
// }

// #include <iostream>

// int main() {
//     int A;
//     std::cout << "Число A: ";
//     std::cin >> A;

//     // Логічна змінна приймає значення true, якщо A > 0, і false в іншому випадку
//     bool is_positive = (A > 0);

//     if (is_positive) {
//         std::cout << "А ІСТИННЕ" << std::endl;
//     } else {
//         std::cout << "А хибне" << std::endl;
//     }

//     return 0;
// }

#include <iostream>
#include <cmath> // Необхідно для математичних функцій

int main() {
    double y;
    std::cout << "Введіть значення y: ";
    std::cin >> y;

    // Обчислення чисельника та знаменника
    double upper = std::cbrt(
        std::abs(y * y - 2) * 
        std::abs(std::sin(y * y * y)) * 
        std::abs(std::tan(y)) * 
        std::pow(2.5, std::cos(y))
    );

    double bottom = 0.625 * y + 2 * std::log2(y * y * y + 7.5);

    // Перевірка, щоб уникнути ділення на нуль
    if (denominator == 0) {
        std::cout << "Ділення на нуль!" << std::endl;
    } else {
        double y = upper / bottom;
        std::cout << "y = " << y << std::endl;
    }

    return 0;
}